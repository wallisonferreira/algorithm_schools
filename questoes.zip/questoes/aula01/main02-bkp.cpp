#include <iostream>
#include <vector>

using namespace std;

int main() {

    int qtd;
    cin >> qtd;

    vector<int> numeros(qtd);
    for(int i=0; i<qtd; i++) {
        cin >> numeros[i];
    }

    int soma=0;
    for (auto n: numeros) {
        soma += n;
    }
    cout << "soma: " << soma << endl;
    return 0;
}