#include <iostream>

using namespace std;

int main() {

    int idade;
    cin >> idade;
    cout << "idade: " << idade << endl;
    return 0;
}