#include <iostream>
#include <vector>

using namespace std;

int main() {

    // velocidade inicial (v) e aceleração constantes
    // velocidade no dobro do tempo?

    int velocidade, tempo;

    while (cin >> velocidade >> tempo) {
        int resultado = velocidade * tempo * 2;
        cout << resultado << endl;
    }
    return 0;
}